# dokc-helm-chart
Custom K8ssandra operator for Date on Kuberenetes' how-to-dok project.
